#include<iostream>
using namespace std;
int main() 
{
	system("taskmgr");
	return 0;
	
}
