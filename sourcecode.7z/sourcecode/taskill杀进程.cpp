#include<iostream>
using namespace std;
int main() 
{
	system("taskkill -f -im StudentMain.exe -t");
	return 0;
	
}
